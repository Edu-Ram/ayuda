const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const User = require('../models/User');
const config = require('../config.json');
const axios = require('axios');

// Middleware para verificar si el ID es válido
const validateObjectId = (req, res, next) => {
  if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }
  next();
};

async function generateKeyPair() {
  const response = await axios.post(`${config.apiUrl}/generate-keys`);
  return response.data;
}

// Registrar un nuevo usuario
router.post('/register', async (req, res) => {
  const { username, password, idNumber, idType, phoneNumber, address } = req.body;

  try {
    let existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(409).json({ message: 'Username already exists' });
    }

    existingUser = await User.findOne({ idNumber });
    if (existingUser) {
      return res.status(403).json({ message: 'ID number already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const keyPair = await generateKeyPair();
    const newUser = new User({
      username,
      password: hashedPassword,
      idNumber,
      idType,
      phoneNumber,
      address,
      publicKey: keyPair.publicKey,
      privateKey: keyPair.privateKey,
    });

    await newUser.save();
    return res.status(201).json({
      message: 'User registered successfully',
      username,
      idNumber,
      idType,
      phoneNumber,
      address,
      publicKey: keyPair.publicKey,
      privateKey: keyPair.privateKey,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error registering user', error });
  }
});

// Obtener todos los usuarios
router.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching users', error });
  }
});

// Obtener un usuario por ID
router.get('/users/:id', validateObjectId, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching user', error });
  }
});

// Actualizar un usuario
router.put('/users/:id', validateObjectId, async (req, res) => {
  const { username, password, idNumber, idType, phoneNumber, address } = req.body;
  const updates = { username, idNumber, idType, phoneNumber, address };

  if (password) {
    updates.password = await bcrypt.hash(password, 10);
  }

  try {
    const user = await User.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating user', error });
  }
});

// Borrar un usuario
router.delete('/users/:id', validateObjectId, async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error deleting user', error });
  }
});

module.exports = router;
