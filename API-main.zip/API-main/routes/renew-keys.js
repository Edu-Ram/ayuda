const express = require('express');
const router = express.Router();
const axios = require('axios');
const User = require('../models/User');
const config = require('../config.json');

async function generateKeyPair() {
  const response = await axios.post(`${config.apiUrl}/generate-keys`);
  return response.data;
}

router.post('/renew-key', async (req, res) => {
  const { idNumber, idType } = req.body;

  try {
    const user = await User.findOne({ idNumber, idType });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const keyPair = await generateKeyPair();

    user.publicKey = keyPair.publicKey;
    user.privateKey = keyPair.privateKey;
    await user.save();

    return res.status(200).json({ message: 'Keys renewed successfully' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error renewing keys', error });
  }
});

module.exports = router;