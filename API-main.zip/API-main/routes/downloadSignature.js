const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.get('/download-signature', async (req, res) => {
  const { idNumber, idType } = req.query;

  try {
    // Busca al usuario en la base de datos
    const user = await User.findOne({ idNumber, idType });

    // Verifica si el usuario existe
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Obtiene la firma digital del usuario
    const digitalSign = user.digital_sign;

    // Verifica si la firma digital está disponible
    if (!digitalSign) {
      return res.status(400).json({ message: 'Digital signature not available' });
    }

    // Configura el nombre y tipo de archivo
    const filename = `digital-signature-${idNumber}.pem`;
    const contentType = 'text/plain';

    // Configura los headers para la descarga del archivo
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', contentType);

    // Envía la firma digital como respuesta
    res.send(digitalSign);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error downloading digital signature', error });
  }
});

module.exports = router;
