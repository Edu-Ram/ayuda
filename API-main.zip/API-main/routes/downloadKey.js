const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.get('/download-key', async (req, res) => {
  const { idNumber, idType, keyType } = req.query;

  try {
    // Verifica el tipo de llave solicitado
    if (keyType !== 'private' && keyType !== 'public') {
      return res.status(400).json({ message: 'Invalid key type. Use "private" or "public".' });
    }

    // Busca al usuario en la base de datos
    const user = await User.findOne({ idNumber, idType });

    // Verifica si el usuario existe
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Obtiene la llave solicitada
    const key = keyType === 'private' ? user.privateKey : user.publicKey;

    // Verifica si la llave está disponible
    if (!key) {
      return res.status(400).json({ message: `${keyType.charAt(0).toUpperCase() + keyType.slice(1)} key not available` });
    }

    // Configura el nombre y tipo de archivo
    const filename = `${keyType}-key-${idNumber}.pem`;
    const contentType = 'application/x-pem-file';

    // Configura los headers para la descarga del archivo
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', contentType);

    // Envía el contenido de la llave como respuesta
    res.send(key);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error downloading key', error });
  }
});

module.exports = router;
