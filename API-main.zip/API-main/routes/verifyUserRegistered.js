const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const User = require('../models/User');

router.post('/login', async (req, res) => {
  const { idNumber } = req.body;

  try {
    const user = await User.findOne({ idNumber });

    existingUser = await User.findOne({ idNumber });
    if (existingUser) {
      return res.status(403).json({ message: 'True' });
    }

  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error during verification', error });
  }
});

module.exports = router;
