const express = require('express');
const router = express.Router();
const axios = require('axios');
const User = require('../models/User');
const config = require('../config.json');

router.post('/renew-signature', async (req, res) => {
    const { idNumber, idType } = req.body;
  
    try {
      const user = await User.findOne({ idNumber, idType });
  
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      const response = await axios.post(`${config.apiUrl}/sign`, {
        privateKey: user.privateKey
      });
  
      user.digital_sign = response.data.signature;
      await user.save();
  
      return res.status(200).json({ message: 'Signature renewed successfully', sign: user.digital_sign });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ message: 'Error renewing signature', error });
    }
  });

  module.exports = router;