const express = require('express');
const router = express.Router();
const axios = require('axios');
const bcrypt = require('bcrypt');
const User = require('../models/User');
const config = require('../config.json');

async function generateKeyPair() {
  const response = await axios.post(`${config.apiUrl}/generate-keys`);
  return response.data;
}

router.post('/register', async (req, res) => {
  const { username, password, idNumber, idType, phoneNumber, address } = req.body;

  try {
    let existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(409).json({ message: 'Username already exists' });
    }

    existingUser = await User.findOne({ idNumber });
    if (existingUser) {
      return res.status(403).json({ message: 'ID number already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 10); // 10 es el número de rondas de hashing

    const keyPair = await generateKeyPair();
    const newUser = new User({
      username,
      password: hashedPassword,
      idNumber,
      idType,
      phoneNumber,
      address,
      publicKey: keyPair.publicKey,
      privateKey: keyPair.privateKey,
    });

    await newUser.save();
    return res.status(201).json({
      message: 'User registered successfully',
      username,
      idNumber,
      idType,
      phoneNumber,
      address,
      publicKey: keyPair.publicKey,
      privateKey: keyPair.privateKey,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Error registering user', error });
  }
});

module.exports = router;
