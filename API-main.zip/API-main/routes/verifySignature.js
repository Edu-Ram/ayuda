const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs');
const User = require('../models/User');
const config = require('../config.json');

// Configurar multer para manejar la subida de archivos
const upload = multer({ dest: 'uploads/' });

router.post('/validate-signature', upload.single('publicKeyFile'), async (req, res) => {
  const { idNumber, idType, signature } = req.body;
  const publicKeyFile = req.file;

  if (!publicKeyFile) {
    return res.status(400).json({ message: 'Public key file is required' });
  }

  try {
    const user = await User.findOne({ idNumber, idType });

    if (!user) {
      fs.unlinkSync(publicKeyFile.path);
      return res.status(404).json({ message: 'User not found' });
    }

    const publicKey = fs.readFileSync(publicKeyFile.path, 'utf8').trim();

    // Verificar si la clave pública coincide con la del usuario
    if (publicKey !== user.publicKey.trim()) {
      fs.unlinkSync(publicKeyFile.path);
      return res.status(400).json({ message: 'Public key does not match' });
    }

    // Comparar la firma digital proporcionada con la almacenada
    const storedSignature = user.digital_sign;

    if (signature === storedSignature) {
      fs.unlinkSync(publicKeyFile.path);
      return res.status(200).json({ message: 'Signature is valid' });
    } else {
      fs.unlinkSync(publicKeyFile.path);
      return res.status(401).json({ message: 'Signature is not valid' });
    }
  } catch (error) {
    console.error('Error validating signature:', error);
    fs.unlinkSync(publicKeyFile.path);
    return res.status(500).json({ message: 'Error validating signature', error });
  }
});

module.exports = router;
