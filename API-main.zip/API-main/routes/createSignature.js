const express = require('express');
const router = express.Router();
const axios = require('axios');
const multer = require('multer');
const fs = require('fs');
const User = require('../models/User');
const config = require('../config.json');

// Configurar multer para manejar la subida de archivos
const upload = multer({ dest: 'uploads/' });

router.post('/generate-signature', upload.single('privateKeyFile'), async (req, res) => {
  const { idNumber, idType } = req.body;
  const privateKeyFile = req.file;

  if (!privateKeyFile) {
    return res.status(400).json({ message: 'Private key file is required' });
  }

  try {
    const user = await User.findOne({ idNumber, idType });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const privateKey = fs.readFileSync(privateKeyFile.path, 'utf8').trim();

    // Verificar si la clave privada coincide con la del usuario
    if (privateKey !== user.privateKey.trim()) {
      fs.unlinkSync(privateKeyFile.path);
      return res.status(400).json({ message: 'Private key does not match' });
    }

    if (user.digital_sign) {
      fs.unlinkSync(privateKeyFile.path);
      return res.status(400).json({ message: 'Signature already exists', sign: user.digital_sign });
    }

    // Generar la firma usando la clave privada del usuario
    const response = await axios.post(`${config.apiUrl}/sign`, {
      privateKey: user.privateKey
    });

    user.digital_sign = response.data.signature;
    await user.save();

    // Eliminar el archivo subido después de su uso
    fs.unlinkSync(privateKeyFile.path);

    return res.status(200).json({ message: 'Signature generated and saved successfully', sign: user.digital_sign });
  } catch (error) {
    console.error(error);
    fs.unlinkSync(privateKeyFile.path);
    return res.status(500).json({ message: 'Error generating signature', error });
  }

});

module.exports = router;
