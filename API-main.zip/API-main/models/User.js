const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  username: String,
  password: String,
  idNumber: String,
  idType: String, // fisica / juridica
  phoneNumber: String,
  address: String,
  publicKey: String,
  privateKey: String,
  digital_sign: String,
});

module.exports = mongoose.model('User', UserSchema);
