npm init -y
npm install bcrypt node-forge mongoose cors express app-root-path multer form-data
