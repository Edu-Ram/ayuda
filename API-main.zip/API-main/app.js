const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const config = require('./config.json');

const app = express();

const port = 5001;

app.use(cors());
app.use(express.json());

mongoose.connect(config.mongoUrl)
  .then(() => console.log('Connected to MongoDB'))
  .catch(error => console.error('Error connecting to MongoDB:', error));

require('./models/User');

const indexRouter = require('./routes/index');
const userRouter = require('./routes/user');
const loginRouter = require('./routes/login');
const downloadKeyRouter = require('./routes/downloadKey');
const verifySignatureRouter = require('./routes/verifySignature');
const createSignatureRouter = require('./routes/createSignature');
const renewKeysRouter = require('./routes/renew-keys');
const renewSignatureRouter = require('./routes/renew-signature');
const downloadSignatureRouter = require('./routes/downloadSignature');

app.use('/', indexRouter);
app.use('/bank', userRouter);
app.use('/bank', loginRouter);
app.use('/bank', downloadKeyRouter);
app.use('/bank', verifySignatureRouter);
app.use('/bank', createSignatureRouter);
app.use('/bank', renewKeysRouter);
app.use('/bank', renewSignatureRouter);
app.use('/bank', downloadSignatureRouter);

app.listen(port, () => {
  console.log(`API listening on port ${port}`);
});
